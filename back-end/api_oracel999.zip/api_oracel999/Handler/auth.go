package handlers

import (
	"my-go-project/models"
	"net/http"

	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
)

// RegisterHandler รับคำขอการสมัครสมาชิก
// RegisterHandler รับคำขอสมัครสมาชิก
func RegisterHandler(c *gin.Context, db *gorm.DB) {
	var json models.User
	if err := c.ShouldBindJSON(&json); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// เข้ารหัสรหัสผ่านก่อนบันทึก
	encryptedPassword, err := bcrypt.GenerateFromPassword([]byte(json.Password), 10)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to encrypt password"})
		return
	}
	json.Password = string(encryptedPassword)

	// บันทึกข้อมูลผู้ใช้ใหม่
	result := db.Create(&json)
	if result.Error != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": result.Error.Error()})
		return
	}

	// ตรวจสอบว่าข้อมูลถูกบันทึกสำเร็จ
	if json.UserID > 0 {
		c.JSON(http.StatusOK, gin.H{
			"status":  "ok",
			"userID":  json.UserID,
			"message": "User successfully created",
		})
	} else {
		c.JSON(http.StatusInternalServerError, gin.H{
			"status":  "error",
			"message": "User creation failed",
		})
	}
}

// LoginHandler รับคำขอล็อกอิน
func LoginHandler(c *gin.Context, db *gorm.DB) {
	var input struct {
		Email    string `json:"email" binding:"required,email"`
		Password string `json:"password" binding:"required"`
	}

	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// ค้นหาผู้ใช้ในฐานข้อมูลs
	var user models.User
	result := db.Where("email = ?", input.Email).First(&user)
	if result.Error != nil {
		c.JSON(http.StatusUnauthorized, gin.H{"status": "error", "message": "Invalid email"})
		return
	}

	// ตรวจสอบรหัสผ่านที่เข้ารหัส
	err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(input.Password))
	if err != nil {
		c.JSON(http.StatusUnauthorized, gin.H{"status": "error", "message": "Invalid password"})
		return
	}

	// ถ้าทุกอย่างถูกต้อง
	c.JSON(http.StatusOK, gin.H{
		"status":  "success",
		"userID":  user.UserID, // ใช้ user.UserID แทน user.ID
		"message": "Login successful",
	})
}
