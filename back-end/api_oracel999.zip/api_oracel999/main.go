package main

import (
	handlers "my-go-project/Handler" // การ import จาก package handlers
	"my-go-project/database"         // การ import จาก package database

	"github.com/gin-gonic/gin"
)

func main() {
	// ตั้งค่าการเชื่อมต่อฐานข้อมูล
	db, err := database.SetupDatabaseConnection()
	if err != nil {
		panic("Failed to connect to the database")
	}

	// สร้าง Gin router
	r := gin.Default()

	// ตั้งค่า route สำหรับการสมัครสมาชิก
	r.POST("/register", func(c *gin.Context) {
		handlers.RegisterHandler(c, db)
	})

	// ตั้งค่า route สำหรับการล็อกอิน
	r.POST("/login", func(c *gin.Context) {
		handlers.LoginHandler(c, db)
	})

	// เริ่มรันเซิร์ฟเวอร์
	r.Run(":8080")
}
