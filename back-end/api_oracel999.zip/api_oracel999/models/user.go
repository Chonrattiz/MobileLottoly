package models

type User struct {
	UserID   uint    `json:"user_id" gorm:"primaryKey;column:user_id"` // กำหนดให้ใช้คอลัมน์ user_id
	Username string  `json:"username" binding:"required"`
	Email    string  `json:"email" binding:"required,email"`
	Password string  `json:"password" binding:"required"`
	Role     string  `json:"role" binding:"required,oneof=member admin"`
	Wallet   float64 `json:"wallet" binding:"required"`
}

// กำหนดให้ GORM ใช้ชื่อ "User" เป็นชื่อตารางในฐานข้อมูล
func (User) TableName() string {
	return "User" // หรือจะใช้ชื่อฐานข้อมูลที่ต้องการ เช่น "users"
}
